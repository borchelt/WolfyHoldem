extends Node2D
@export var button: TextureButton
@export var tradeButton: TextureButton
@export var label: Label
@export var audio: AudioStreamPlayer2D
@export var deal1: AudioStreamOggVorbis
@export var deal2: AudioStreamOggVorbis
@export var deal3: AudioStreamOggVorbis
@export var deal4: AudioStreamOggVorbis
@export var deal5: AudioStreamOggVorbis
@export var deal6: AudioStreamOggVorbis
@export var deal7: AudioStreamOggVorbis
@export var deal8: AudioStreamOggVorbis
@export var deal9: AudioStreamOggVorbis
var card = preload("res://prefabs/card.tscn")
var dealcd = 0.0
var deck = []
var numburned = 0
var river = []
var hole = []
var shop = []
var stage = 0
var tradesLeft = 0
var audiowheel = [deal1,deal2,deal3,deal4,deal5,deal6,deal7,deal8,deal9]
# Called when the node enters the scene tree for the first time.
func _ready():
	button.pressed.connect(deal)
	tradeButton.pressed.connect(trade)
func _process(delta):
	if(dealcd > 0.0):
		dealcd -= 1.0*delta
	else:
		dealcd = 0
		
func deal():
	if(stage == 4):
		stage = 0
		river = []
		hole = []
		shop = []
	numburned = 0
	if(dealcd != 0):
		return
		
	dealcd = 0.15
	if(stage == 0):
		for child in get_children():
			if child is Card:
				child.queue_free()
	

	var suits = ["Diamond", "Club", "Spade", "Heart"]
	var nums = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14"]
	var stages = [0, 4, 2, 2, 2]
	
	if(stage == 0):
		for i in range(4):
			var suit = suits[i]
			for f in range(13):
				var fcard = [suit, nums[f]]
				deck.append(fcard)
				
		for i in range(7):
			deck.shuffle()
	
	await dealCard(stages[stage],"river")
	
	if(stage == 0):
		await dealCard(2,"hole")
		await dealCard(3,"shop")
		
	stage+=1
	tradesLeft=1
	handCheck()
	
	
func trade():
	if(tradesLeft < 1):
		return
	else:
		tradesLeft-=1
	var selectedShop
	var selectednum = 0
	var delindexhole
	var delindexchild
	var childCard
	var holeCard
	for child in get_children():
		if(child is Card):
			if(child.selected && selectednum < 2):
				selectednum+=1
				match child.pool:
					"hole":
						delindexhole = child.index
						holeCard = child
						
					"shop":
						delindexchild = child.index
						childCard = child
					
	if(selectednum != 2):
		tradesLeft=1
		return "done"
	var newCard = card.instantiate()
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	var my_random_numberY = rng.randi_range(-10, 10)
	var my_random_numberX = rng.randi_range(-10, 10)
	var offset = 1.0
	var bigoffset = 280
	var vec2 = Vector2( bigoffset + float((1*offset) + my_random_numberX), 260 + my_random_numberY)
	newCard.global_position = vec2
	newCard.suit = childCard.suit
	newCard.number = childCard.number
	newCard.facing = "UP"
	newCard.pool = "hole"
	newCard.index = delindexhole
	newCard.selected = false
	add_child(newCard)

	hole.pop_at(hole.find({"suit": holeCard.suit, "number": holeCard.number}))
	shop.pop_at(shop.find({"suit": newCard.suit, "number": newCard.number}))

	hole.append({"suit": newCard.suit, "number": newCard.number})
	dealCard(1, "shop")
	childCard.queue_free()
	holeCard.queue_free()
	handCheck()
	return

func handCheck():
	var allCards = []
	allCards.append_array(river)

	allCards.append_array(hole)
	print("====")
	print(hole)
	print(river)
	print(allCards.size())
	print("====")
	#count all suits
	
	var spades = 0
	var clubs = 0
	var hearts= 0
	var diamonds = 0
	var numbers = []
	for card in allCards:
		match card.suit:
			"Spade": spades+=1
			"Diamond": diamonds+=1
			"Club": clubs+=1
			"Heart": hearts +=1
		numbers.append(int(card.number))

	numbers.sort()
	print(numbers)
	var hand = "NOTHING!"
	
	#check for straight
	var lastnum = null
	var straightcount = 1
	var highestSC = 1
	var hadAceStraight = false
	var numPairs = 0
	var numThrees = 0
	var numFours = 0
	for i in range(numbers.size()):

		var numOfCard = numbers.count(numbers[i])
		if(numOfCard == 4):
			numFours +=1
		elif(numOfCard == 3):
			numThrees +=1
		elif(numOfCard == 2):
			numPairs +=1
		
		if (lastnum == null):
			lastnum = numbers[i-1]
		else:
			if (numbers[i-1] == lastnum+1):
				straightcount+= 1
			elif(numbers[i-1] == 14 && numbers[0] == 1 && hadAceStraight == false):
				straightcount +=1
				hadAceStraight = true
			elif(numbers[i-1] == lastnum):
				pass
			else:
				if(straightcount > highestSC):
					highestSC = straightcount
				straightcount = 1
			if(straightcount > highestSC):
					highestSC = straightcount
			lastnum = numbers[i-1]
	lastnum = null
	if(numPairs/2 == 1):
		hand = "pair!"
	elif(numPairs/2 > 1):
		hand="two pair!!"
	if(numThrees/3 == 1):
		if(hand == "pair!" || hand == "two pair!!"):
			hand = "full house!!!!"
		else:
			hand = "three of a kind!!!"
	elif(numThrees/3 > 1):
		hand = "full house!!!!"
		
	if(highestSC >= 5):
		hand = "straight!!!!!"
	if(numFours/4 == 1):
		hand = "four of a kind!!!!"
	if(spades > 4 || clubs >4 || hearts > 4 || diamonds > 4):
		if(hand == "straight!!!!!"):
			hand = "straight flush!!!!!"
		elif(hand=="four of a kind!!!!"):
			pass
		else:
			hand = "flush!!!!!!"
	
	label.text = hand
	

func dealCard(num, pool, index: int = -1) -> String:
	if(num == 0):
		return "done"
	var indexedDeal = false

	audiowheel = [deal1,deal2,deal3,deal4,deal5,deal6,deal7,deal8,deal9]
	for i in range(num):
		var ind = i
		if(index != -1):
			ind = index
		
		await get_tree().create_timer(.01).timeout 
		match pool:
			"river":
				print("river")
				audiowheel.shuffle()
				audio.stream = audiowheel[0]
				audio.play()
				audiowheel.pop_front()
				
				#burn cards
				if(i == 0 || i == 4 ||i == 6 ):
					numburned+=1
					deck.pop_front()
					continue
				var g = ind-numburned
				
				var newCard = card.instantiate()
				var rng = RandomNumberGenerator.new()
				rng.randomize()
				var my_random_numberY = rng.randi_range(-10, 10)
				var my_random_numberX = rng.randi_range(-10, 10)
				var offset = 10
				var bigoffset = 280
				var vec2 = Vector2( bigoffset + float((g*offset) + my_random_numberX), 100 + my_random_numberY)
				newCard.global_position = vec2
				newCard.suit = deck[0][0]
				newCard.number = deck[0][1]
				newCard.facing = "UP"
				newCard.pool = "river"
				newCard.index = g
				newCard.selected = false
				add_child(newCard)
				river.append({"suit": deck[0][0], "number": deck[0][1]})
				deck.pop_front()
			
				
			"hole":
				audiowheel.shuffle()
				audio.stream = audiowheel[0]
				audio.play()
				audiowheel.pop_front()
				print("hole") 
				var newCard = card.instantiate()
				var rng = RandomNumberGenerator.new()
				rng.randomize()
				var my_random_numberY = rng.randi_range(-10, 10)
				var my_random_numberX = rng.randi_range(-10, 10)
				var offset = 1.0
				var bigoffset = 280
				var vec2 = Vector2( bigoffset + float((ind*offset) + my_random_numberX), 260 + my_random_numberY)
				newCard.global_position = vec2
				newCard.suit = deck[0][0]
				newCard.number = deck[0][1]
				newCard.facing = "UP"
				newCard.pool = "hole"
				newCard.index = ind
				newCard.selected = false
				add_child(newCard)
				hole.append({"suit": deck[0][0], "number": deck[0][1]})
				deck.pop_front()
			"shop":
				audiowheel.shuffle()
				audio.stream = audiowheel[0]
				audio.play()
				audiowheel.pop_front()
				print("shop")
				
				var newCard = card.instantiate()
				var rng = RandomNumberGenerator.new()
				rng.randomize()
				var my_random_numberY = rng.randi_range(-10, 10)
				var my_random_numberX = rng.randi_range(-10, 10)
				var offset = 1.0
				var bigoffset = 500
				var vec2 = Vector2( bigoffset + my_random_numberX, 175 + float((ind*offset) + my_random_numberY))
				newCard.global_position = vec2
				newCard.rotation = deg_to_rad(90.0)
				newCard.suit = deck[0][0]
				newCard.number = deck[0][1]
				newCard.facing = "DOWN"
				newCard.pool = "shop"
				newCard.index = ind
				newCard.selected = false
				add_child(newCard)
				shop.append({"suit": deck[0][0], "number": deck[0][1]})
				deck.pop_front()
	
	return "done"
